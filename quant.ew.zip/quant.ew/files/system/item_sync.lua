-- Synchronizes item pickup and item drop
local inventory_helper = dofile_once("mods/quant.ew/files/core/inventory_helper.lua")
local ctx = dofile_once("mods/quant.ew/files/core/ctx.lua")
local net = dofile_once("mods/quant.ew/files/core/net.lua")

dofile_once("data/scripts/lib/coroutines.lua")

local rpc = net.new_rpc_namespace()

local item_sync = {}

local pending_remove = {}
local pickup_handlers = {}

function item_sync.ensure_notify_component(ent)
    local notify = EntityGetFirstComponentIncludingDisabled(ent, "LuaComponent", "ew_notify_component")
    if notify == nil then
        EntityAddComponent2(ent, "LuaComponent", {
            _tags = "enabled_in_world,enabled_in_hand,enabled_in_inventory,ew_notify_component",
            script_throw_item = "mods/quant.ew/files/resource/cbs/item_notify.lua",
            script_item_picked_up = "mods/quant.ew/files/resource/cbs/item_notify.lua",
        })
    end
end

local function mark_in_inventory(my_player)
    local items = inventory_helper.get_all_inventory_items(my_player)
    for _, ent in pairs(items) do
        item_sync.ensure_notify_component(ent)
    end
end

local function allocate_global_id()
    local current = tonumber(GlobalsGetValue("ew_global_item_id", "1"))
    GlobalsSetValue("ew_global_item_id", tostring(current + 1))
    return ctx.my_player.peer_id .. ":" .. current
end

local function is_item_on_ground(item)
    return EntityGetComponent(item, "SimplePhysicsComponent") ~= nil
        or EntityGetComponent(item, "PhysicsBodyComponent") ~= nil
        or EntityGetComponent(item, "SpriteParticleEmitterComponent") ~= nil
end

function item_sync.get_global_item_id(item)
    local gid = EntityGetFirstComponentIncludingDisabled(item, "VariableStorageComponent", "ew_global_item_id")
    if gid == nil then
        return nil
    end
    return ComponentGetValue2(gid, "value_string")
end

local function is_wand(ent)
    if ent == nil or ent == 0 then
        return false
    end
    local ability = EntityGetFirstComponentIncludingDisabled(ent, "AbilityComponent")
    if ability == nil then
        return false
    end
    return ComponentGetValue2(ability, "use_gun_script") == true
end

local function is_spell(ent)
    return ent ~= nil and ent ~= 0 and EntityHasTag(ent, "card_action") and not is_wand(ent)
end

local function is_perk(ent)
    return ent ~= nil and ent ~= 0 and EntityGetFilename(ent) == "data/entities/items/pickup/perk.xml"
end

local function should_duplicate_loot(ent)
    if is_wand(ent) and ctx.proxy_opt.duplicate_wands then
        return true
    end
    if is_spell(ent) and ctx.proxy_opt.duplicate_spells then
        return true
    end
    if is_perk(ent) and ctx.proxy_opt.duplicate_perks then
        return true
    end
    return false
end

local function get_loot_key(item)
    local loot_key = EntityGetFirstComponentIncludingDisabled(item, "VariableStorageComponent", "ew_loot_key")
    if loot_key ~= nil then
        return ComponentGetValue2(loot_key, "value_string")
    end
    local f = EntityGetFilename(item)
    local x, y = EntityGetTransform(item)
    return f .. ":" .. math.floor(x) .. ":" .. math.floor(y)
end

local function ensure_loot_key(item)
    if EntityGetFirstComponentIncludingDisabled(item, "VariableStorageComponent", "ew_loot_key") ~= nil then
        return
    end
    EntityAddComponent2(item, "VariableStorageComponent", {
        _tags = "ew_loot_key",
        value_string = get_loot_key(item),
    })
end

local function mark_loot_claimed(item)
    if not should_duplicate_loot(item) then
        return
    end
    if EntityGetFirstComponentIncludingDisabled(item, "VariableStorageComponent", "ew_loot_key") == nil then
        return
    end
    ctx.claimed_loot_keys[get_loot_key(item)] = true
end

function item_sync.remove_item_with_id(gid)
    table.insert(pending_remove, gid)
end

local find_by_gid_cache = {}
function item_sync.find_by_gid(gid)
    if find_by_gid_cache[gid] ~= nil and EntityGetIsAlive(find_by_gid_cache[gid]) then
        return find_by_gid_cache[gid]
    end

    for _, item in ipairs(EntityGetWithTag("ew_global_item") or {}) do
        local i_gid = item_sync.get_global_item_id(item)
        if i_gid ~= nil then
            find_by_gid_cache[i_gid] = item
            if i_gid == gid then
                return item
            end
        end
    end
end

function item_sync.remove_item_with_id_now(gid)
    find_by_gid_cache[gid] = nil
    for _, item in ipairs(EntityGetWithTag("ew_global_item") or {}) do
        local i_gid = item_sync.get_global_item_id(item)
        if i_gid == gid then
            EntityKill(item)
            return
        end
    end
end

function item_sync.host_localize_item(gid, peer_id)
    if ctx.item_prevent_localize[gid] then
        return
    end
    ctx.item_prevent_localize[gid] = true

    if table.contains(pending_remove, gid) then
        return
    end

    local item_ent_id = item_sync.find_by_gid(gid)
    if item_ent_id ~= nil then
        for _, handler in ipairs(pickup_handlers) do
            handler(item_ent_id)
        end
    end
    if peer_id ~= ctx.my_id then
        item_sync.remove_item_with_id(gid)
    end
    rpc.item_localize(peer_id, gid)
end

function item_sync.make_item_global(item, instant)
    EntityAddTag(item, "ew_global_item")
    async(function()
        if not instant then
            wait(1)
        end
        if not EntityGetIsAlive(item) then
            return
        end
        item_sync.ensure_notify_component(item)
        local gid_component =
            EntityGetFirstComponentIncludingDisabled(item, "VariableStorageComponent", "ew_global_item_id")
        local gid
        if gid_component == nil then
            gid = allocate_global_id()
            EntityAddComponent2(item, "VariableStorageComponent", {
                _tags = "enabled_in_world,enabled_in_hand,enabled_in_inventory,ew_global_item_id",
                value_string = gid,
            })
        else
            gid = ComponentGetValue2(gid_component, "value_string")
        end
        if should_duplicate_loot(item) then
            ensure_loot_key(item)
        end
        local item_data = inventory_helper.serialize_single_item(item)
        item_data.gid = gid
        ctx.item_prevent_localize[gid] = false
        rpc.item_globalize(item_data)
    end)
end

local function get_global_ent(key)
    local val = tonumber(GlobalsGetValue(key, "0"))
    GlobalsSetValue(key, "0")
    if val ~= 0 then
        return val
    end
end

local function remove_client_items_from_world()
    if GameGetFrameNum() % 5 ~= 3 then
        return
    end
    for _, item in ipairs(EntityGetWithTag("ew_client_item") or {}) do
        if is_item_on_ground(item) then
            EntityKill(item)
        end
    end
end

local function globalize_duplicate_loot_on_ground()
    if not ctx.is_host then
        return
    end
    if GameGetFrameNum() % 120 ~= 35 then
        return
    end
    if ctx.proxy_opt.duplicate_wands then
        for _, wand in ipairs(EntityGetWithTag("wand") or {}) do
            if is_item_on_ground(wand) and not EntityHasTag(wand, "ew_global_item") then
                item_sync.make_item_global(wand, true)
            end
        end
    end
    if ctx.proxy_opt.duplicate_spells then
        for _, ent in ipairs(EntityGetWithTag("card_action") or {}) do
            if is_spell(ent) and is_item_on_ground(ent) and not EntityHasTag(ent, "ew_global_item") then
                item_sync.make_item_global(ent, true)
            end
        end
    end
    if ctx.proxy_opt.duplicate_perks then
        for _, ent in ipairs(EntityGetWithTag("item_pickup") or {}) do
            if is_perk(ent) and is_item_on_ground(ent) and not EntityHasTag(ent, "ew_global_item") then
                item_sync.make_item_global(ent, true)
            end
        end
    end
end

function item_sync.on_world_update_host()
    local my_player = ctx.my_player
    if GameGetFrameNum() % 5 == 4 then
        mark_in_inventory(my_player)
    end
    local thrown_item = get_global_ent("ew_thrown")
    if thrown_item ~= nil then
        item_sync.make_item_global(thrown_item)
    end
    local picked_item = get_global_ent("ew_picked")
    if picked_item ~= nil and EntityHasTag(picked_item, "ew_global_item") then
        mark_loot_claimed(picked_item)
        local gid = item_sync.get_global_item_id(picked_item)
        if gid ~= nil then
            item_sync.host_localize_item(gid, ctx.my_id)
        end
    end
    globalize_duplicate_loot_on_ground()
    remove_client_items_from_world()
end

function item_sync.on_world_update_client()
    local my_player = ctx.my_player
    if GameGetFrameNum() % 5 == 4 then
        mark_in_inventory(my_player)
    end
    local thrown_item = get_global_ent("ew_thrown")
    if thrown_item ~= nil and not EntityHasTag(thrown_item, "ew_client_item") then
        item_sync.make_item_global(thrown_item)
    end

    local picked_item = get_global_ent("ew_picked")
    if picked_item ~= nil and EntityHasTag(picked_item, "ew_global_item") then
        mark_loot_claimed(picked_item)
        local gid = item_sync.get_global_item_id(picked_item)
        if gid ~= nil then
            rpc.item_localize_req(gid)
        end
    end
    remove_client_items_from_world()
end

local function is_safe_to_remove()
    return not ctx.is_wand_pickup
end

function item_sync.on_world_update()
    if is_safe_to_remove() then
        if #pending_remove > 0 then
            local gid = table.remove(pending_remove)
            item_sync.remove_item_with_id_now(gid)
        end
    end
end

function item_sync.on_should_send_updates()
    if not ctx.is_host then
        return
    end
    local item_list = {}
    for _, item in ipairs(EntityGetWithTag("ew_global_item") or {}) do
        if is_item_on_ground(item) then
            local item_data = inventory_helper.serialize_single_item(item)
            local gid = item_sync.get_global_item_id(item)
            if gid ~= nil then
                item_data.gid = gid
                table.insert(item_list, item_data)
            end
        end
    end
    rpc.initial_items(item_list)
end

function item_sync.on_draw_debug_window(imgui)
    local mx, my = DEBUG_GetMouseWorld()
    local ent = EntityGetClosestWithTag(mx, my, "ew_global_item")
    if ent ~= nil and ent ~= 0 then
        if imgui.CollapsingHeader("Item gid") then
            local x, y = EntityGetTransform(ent)
            GameCreateSpriteForXFrames("mods/quant.ew/files/resource/debug/marker.png", x, y, true, 0, 0, 1, true)
            local gid = item_sync.get_global_item_id(ent)
            imgui.Text("GID: " .. tostring(gid))
            local prevented = ctx.item_prevent_localize[gid]
            if prevented then
                imgui.Text("Localize prevented")
            else
                imgui.Text("Localize allowed")
            end
        end
    end
end

local function add_stuff_to_globalized_item(item, gid)
    EntityAddTag(item, "ew_global_item")
    item_sync.ensure_notify_component(item)
    local gid_c = EntityGetFirstComponentIncludingDisabled(item, "VariableStorageComponent", "ew_global_item_id")
    if gid_c == nil then
        EntityAddComponent2(item, "VariableStorageComponent", {
            _tags = "ew_global_item_id",
            value_string = gid,
        })
    else
        ComponentSetValue2(gid_c, "value_string", gid)
    end
    ctx.item_prevent_localize[gid] = false
end

local function maybe_disable_physics(item_new)
    local x, y = EntityGetTransform(item_new)
    if not DoesWorldExistAt(x - 5, y - 5, x + 5, y + 5) then
        async(function()
            wait(1)
            local simple_physics_component = EntityGetFirstComponent(item_new, "SimplePhysicsComponent")
            if simple_physics_component ~= nil and simple_physics_component ~= 0 then
                EntitySetComponentIsEnabled(item_new, simple_physics_component, false)
            end
            local velocity = EntityGetFirstComponent(item_new, "VelocityComponent")
            if velocity ~= nil and velocity ~= 0 then
                EntitySetComponentIsEnabled(item_new, velocity, false)
            end
        end)
    end
end

local function spawn_local_loot_copy(item)
    local item_data = inventory_helper.serialize_single_item(item)
    local copy = inventory_helper.deserialize_single_item(item_data)
    local gid = allocate_global_id()
    add_stuff_to_globalized_item(copy, gid)
    ensure_loot_key(copy)
    maybe_disable_physics(copy)
end

rpc.opts_reliable()
function rpc.initial_items(item_list)
    if GameHasFlagRun("ew_initial_items") then
        return
    end
    GameAddFlagRun("ew_initial_items")
    for _, item_data in ipairs(item_list) do
        local item = item_sync.find_by_gid(item_data.gid)
        if item == nil then
            local item_new = inventory_helper.deserialize_single_item(item_data)
            add_stuff_to_globalized_item(item_new, item_data.gid)
            maybe_disable_physics(item_new)
        end
    end
end

rpc.opts_reliable()
function rpc.item_globalize(item_data)
    if is_safe_to_remove() then
        item_sync.remove_item_with_id_now(item_data.gid)
    end
    local item = inventory_helper.deserialize_single_item(item_data)
    add_stuff_to_globalized_item(item, item_data.gid)
    maybe_disable_physics(item)
end

rpc.opts_reliable()
function rpc.item_localize(l_peer_id, item_id)
    local item_ent_id = item_sync.find_by_gid(item_id)
    if item_ent_id ~= nil then
        for _, handler in ipairs(pickup_handlers) do
            handler(item_ent_id)
        end
    end
    if l_peer_id ~= ctx.my_id then
        if
            item_ent_id ~= nil
            and should_duplicate_loot(item_ent_id)
            and EntityGetFirstComponentIncludingDisabled(item_ent_id, "VariableStorageComponent", "ew_loot_key") ~= nil
            and not ctx.claimed_loot_keys[get_loot_key(item_ent_id)]
        then
            spawn_local_loot_copy(item_ent_id)
        end
        item_sync.remove_item_with_id(item_id)
    end
end

rpc.opts_reliable()
function rpc.item_localize_req(gid)
    if not ctx.is_host then
        return
    end
    item_sync.host_localize_item(gid, ctx.rpc_peer_id)
end

ctx.cap.item_sync = {
    globalize = item_sync.make_item_global,
    register_pickup_handler = function(handler)
        table.insert(pickup_handlers, handler)
    end,
}

return item_sync
